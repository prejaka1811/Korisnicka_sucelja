# Class Projects Related Information

References to class projects:

- [Class project 1: [short title]](/class-projects/class-project-1/)
- [Class project 2: [short title]](/class-projects/class-project-2/)
- ...
